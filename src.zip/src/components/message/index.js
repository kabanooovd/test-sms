import "./index.css";

export const Message = ({text}) => {
  return <div className={"message__wrapper"}>{text}</div>
}